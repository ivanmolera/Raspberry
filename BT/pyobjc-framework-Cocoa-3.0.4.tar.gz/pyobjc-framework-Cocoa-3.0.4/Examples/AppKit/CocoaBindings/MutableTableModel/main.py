#
#  __main__.py
#  TableModel
#
#  Created by Bob Ippolito on Sun Apr 04 2004.
#  Copyright (c) 2004 Bob Ippolito. All rights reserved.
#

from PyObjCTools import AppHelper

# import classes required to start application
import TableModelAppDelegate

# start the event loop
AppHelper.runEventLoop(argv=[])
