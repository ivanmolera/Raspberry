#ifndef PyObjC_OPAQUE_POINTER_H
#define PyObjC_OPAQUE_POINTER_H

extern PyObject* PyObjCCreateOpaquePointerType(const char* name, const char* typestr, const char* docstr);

#endif /* PyObjC_OPAQUE_POINTER_H */
