The following examples don't work correctly yet:
	CIBevelSample
	CIMicroPaint

If someone is bored: please port FunHouse as well.
