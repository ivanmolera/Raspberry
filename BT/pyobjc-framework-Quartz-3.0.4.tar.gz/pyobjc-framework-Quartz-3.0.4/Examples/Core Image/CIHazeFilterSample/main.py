from PyObjCTools import  AppHelper

import HazeFilterView
import MyHazeFilter

import objc; objc.setVerbose(True)

AppHelper.runEventLoop()
