from PyObjCTools import AppHelper
import objc; objc.setVerbose(True)

import CGImageView
import Controller
import CGImageUtils

AppHelper.runEventLoop()
