#ifndef _STDBOOL_H
#define _STDBOOL_H

#if ! defined(__cplusplus)
typedef int bool;
#define false 0
#define true 1
#endif

#define __bool_true_false_are_defined 1

#endif /* _STDBOOL_H */
