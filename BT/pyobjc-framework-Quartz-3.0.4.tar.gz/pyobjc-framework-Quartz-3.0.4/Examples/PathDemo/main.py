from PyObjCTools import AppHelper

import DemoView
import PathDemoController

AppHelper.runEventLoop()
