from PyObjCTools import NibClassBuilder, AppHelper

import ImageBrowserController

import objc; objc.setVerbose(True)

AppHelper.runEventLoop()
